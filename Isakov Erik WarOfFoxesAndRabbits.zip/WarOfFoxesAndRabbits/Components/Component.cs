﻿

using Microsoft.Xna.Framework;

namespace WarOfFoxesAndRabbits
{
    public class Component
    {
        public Vector2 position;
    }
}
