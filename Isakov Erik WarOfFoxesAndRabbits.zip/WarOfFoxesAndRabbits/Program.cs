﻿using var game = new WarOfFoxesAndRabbits.Main();

game.Run();
