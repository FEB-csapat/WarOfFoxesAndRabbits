﻿namespace WarOfFoxesAndRabbits
{
    public abstract class Animal : Entity
    {
        protected double sate;
        protected double maxSate;
        protected int age;
        protected int maxAge;


        public bool hasMoved = false;
        public bool hasProduced = false;


        public double Sate => sate;

        public bool hasAte = false;


        public int Age => age;

      //  public abstract void Eat(int amount);

        public virtual bool IsDead() => Sate <= 0 || age >= maxAge;

        public abstract bool canBreed();

        

        public virtual void Update()
        {
            sate--;
            age++;
        }
    }
}
