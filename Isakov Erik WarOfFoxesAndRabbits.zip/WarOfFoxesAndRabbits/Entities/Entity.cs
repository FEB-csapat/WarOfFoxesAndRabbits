﻿using Microsoft.Xna.Framework;

namespace WarOfFoxesAndRabbits
{
    public abstract class Entity
    {

        public Entity()
        {

        }

        abstract public Color Color
        {
            get;
        }
    }
}
