﻿using Microsoft.Xna.Framework;

namespace WarOfFoxesAndRabbits
{
    class Rabbit : Animal
    {
        private Color color;
        public Rabbit()
        {
            sate = 3;
            age = 0;
            maxSate = 9;
            maxAge = 60;

            hasAte = true;
            hasMoved = true;
            hasProduced = true;

            
        }

        public override Color Color => Color.White;

        public override bool canBreed()
        {
            return sate >= 4;
        }

        public void Eat(double amount)
        {
            if (sate < maxSate)
            {
                sate += amount;
            }
        }

        public bool CanEat(double grassStage)
        {
            return ((grassStage >= 1 && grassStage < 2 && Sate < 5) || grassStage >= 2 && Sate < 4);
        }
    }
}
