﻿using Microsoft.Xna.Framework;

namespace WarOfFoxesAndRabbits
{
    public class Water : Matter
    {
        public Water() : base()
        {

        }

        public override Color Color => Color.DeepSkyBlue;
    }
}
