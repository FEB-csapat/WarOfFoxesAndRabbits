﻿namespace WarOfFoxesAndRabbits
{
    public abstract class Matter : Entity
    {
        public Matter()
        {
        }
    }
}
