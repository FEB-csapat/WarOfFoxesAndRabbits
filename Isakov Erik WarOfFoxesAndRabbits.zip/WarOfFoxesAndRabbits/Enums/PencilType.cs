﻿namespace WarOfFoxesAndRabbits
{
    enum PencilType
    {
        NONE, BUNNY, FOX, WALL, WATER, GRASS
    }
}
